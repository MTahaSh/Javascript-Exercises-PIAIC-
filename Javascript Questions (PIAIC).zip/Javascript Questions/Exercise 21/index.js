let car = "subaru";
let marks = 10;
let movie = "Inception";
let city = "Islamabad";
let country = "Pakistan";
let age = 24;
let day = "Friday";
let month = "December";
let gender = "male";
let bike = "YBR"


console.log("Is car == 'subaru'? I predict True.");
console.log(car == "subaru"? true:false);

console.log("Is marks == 10? I predict True.");
console.log(marks == 10? true:false);
console.log("Is Movie == 'Inception'? I predict True.");
console.log(movie == "Inception"? true:false);
console.log("Is city == 'Islamabad'? I predict True.");
console.log(city == "Islamabad"? true:false);
console.log("Is country == 'Pakistan'? I predict True.");
console.log(country == "Pakistan"? true:false);
console.log("Is age == 31? I predict False.");
console.log(age == 31? true:false);
console.log("Is day == 'Monday'? I predict True.");
console.log(day == "Monday"? true:false);
console.log("Is month == 'September'? I predict True.");
console.log(month == "September"? true:false);
console.log("Is gender == 'female'? I predict True.");
console.log(gender == "female"? true:false);
console.log("Is bike == 'YBR'? I predict True.");
console.log(bike == "Suzuki"? true:false);