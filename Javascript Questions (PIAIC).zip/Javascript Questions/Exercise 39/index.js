let magicians_name = ["David Blaine", "Pen and Teller", "Jerry Sadowitz", "Dynamo"];
show_magicians(magicians_name);

function show_magicians(magicians_name)
{
    for (let index = 0; index < magicians_name.length; index++) {
        console.log(magicians_name[index]);
        
    }
}