var fav_num = 20;

console.log("My favourite number is:", fav_num);