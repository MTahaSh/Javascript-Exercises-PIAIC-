city_country("Rawalpindi","Pakistan")
city_country("Islamabad","Pakistan")
city_country("Lahore","Pakistan")
city_country("Karachi","Pakistan")


function city_country(city,country)
{
    console.log(`${city},${country}`);
}