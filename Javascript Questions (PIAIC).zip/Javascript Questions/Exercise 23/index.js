let alien_color =  "green";

if(alien_color == "green")
{
    console.log("You have just earned 5 points");    
}

alien_color = "yellow";

if(alien_color == "green")
{

}