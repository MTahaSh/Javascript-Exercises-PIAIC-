let car = ["Audi", "Toyota", "Honda","Mercedes","KIA"];

console.log(`I would like to own ${car[0]} car.`);
console.log(`I would like to own ${car[1]} car.`);
console.log(`I would like to own ${car[2]} car.`);
console.log(`I would like to own ${car[3]} car.`);
console.log(`I would like to own ${car[4]} car.`);