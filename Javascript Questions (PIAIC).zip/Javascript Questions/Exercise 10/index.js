let names = ["Junaid", "Kamil", "Shamraiz", "Wajahat"];

console.log(names[0] + ", Meet me tomorrow at restaurant. There is going to be a meetup.");
console.log(names[1] + ", Meet me tomorrow at restaurant. There is going to be a meetup.");
console.log(names[2] + ", Meet me tomorrow at restaurant. There is going to be a meetup.");
console.log(names[3] + ", Meet me tomorrow at restaurant. There is going to be a meetup.");