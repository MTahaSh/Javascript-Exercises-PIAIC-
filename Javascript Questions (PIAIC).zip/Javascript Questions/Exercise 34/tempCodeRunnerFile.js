
// let size = prompt("Enter the size of shirt: ");
// let message = prompt("Enter the message: ");
