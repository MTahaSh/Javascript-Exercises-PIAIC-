
let size = "Medium";
let message = "This shirt belongs to Abdullah";


make_shirt(size,message);

function make_shirt(size,message)
{
    console.log(size);
    console.log(message);

}