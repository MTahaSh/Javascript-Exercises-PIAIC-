//Exercise 9

let names = ["Junaid", "Kamil", "Shamraiz", "Wajahat"];

console.log(names[0]);
console.log(names[1]);
console.log(names[2]);
console.log(names[3]);