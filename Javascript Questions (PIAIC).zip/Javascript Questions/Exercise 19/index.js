let items = ["Mountains", "Rivers", "Countries", "Cities", "Languages"]

console.log(items);