let items = {mountains:"K2", river:"Amazon River", countries:"England", cities:"London", languages:"C++"}

console.log(items);