let pizza_type = ["Veggie Pizza", "Pepperoni Pizza", "Cheese Pizza"];

for (let index = 0; index < pizza_type.length; index++) {
    
    console.log(`I Like ${pizza_type[index]}`);
    
}

console.log("The pizzas mentioned above are the types of pizza I love eating alot.");