let name_str = "\t\t\t\tMuhammad Taha Rizwan\n";

console.log(name_str);


name_str = name_str.trim();
console.log(name_str);