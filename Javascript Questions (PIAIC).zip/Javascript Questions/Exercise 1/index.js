let p_name = "Eric";

console.log("Hello " + p_name + ", would you like to learn some Python today?");