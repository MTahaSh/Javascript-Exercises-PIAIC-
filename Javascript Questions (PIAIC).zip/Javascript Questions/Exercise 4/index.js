let famous_person = "Mae West"
let quote = `${famous_person} once said, "You only live once, but if you do it right, once is enough."`

console.log(quote);