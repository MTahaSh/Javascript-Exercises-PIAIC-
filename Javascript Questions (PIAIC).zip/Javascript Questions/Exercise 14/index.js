let friends = ["Wajahat", "Kamil", "Junaid", "Usman"];

console.log(`Hello ${friends[0]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[1]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[2]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[3]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    

console.log("\n");

console.log(`${friends[3]} cannot join us for the dinner due to which he has been replaced.`);

friends[3] = "Shamraiz";
console.log("\n");


console.log(`Hello ${friends[0]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[1]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[2]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[3]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);  