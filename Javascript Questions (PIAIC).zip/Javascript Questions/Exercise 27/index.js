favourite_fruits = ["mango", "banana", "grapes"];

if(favourite_fruits[0] == "mango")
{
    console.log("You really like mangoes");
}

if(favourite_fruits[1] == "mango")
{
    console.log("You really like mangoes");
}

if(favourite_fruits[2] == "mango")
{
    console.log("You really like mangoes");
}

if(favourite_fruits[0] == "banana")
{
    console.log("You really like bananas");
}
if(favourite_fruits[1] == "banana")
{
    console.log("You really like bananas");
}
if(favourite_fruits[2] == "banana")
{
    console.log("You really like bananas");
}

if(favourite_fruits[0] == "grapes")
{
    console.log("You really like grapes");
}

if(favourite_fruits[1] == "grapes")
{
    console.log("You really like grapes");
}

if(favourite_fruits[2] == "grapes")
{
    console.log("You really like grapes");
}