
let size = "Large";
let size2 = "Medium";
let message = "I love Javascript";
let message2 = "Javascript is fun";
let size3 = "Any";


make_shirt(size,message);
make_shirt(size2,message);
make_shirt(size3,message2);

function make_shirt(size,message)
{
    console.log(size);
    console.log(message);

}