let alien_color = "green";

if(alien_color == "green")
{
    console.log("You have just earned 5 points for shooting the alien");
}

else if(alien_color != "green") 
{
    console.log("You have just earned 10 points");
}


alien_color = "orange";


if(alien_color == "green")
{
    console.log("You have just earned 5 points for shooting the alien");
}

else if(alien_color != "green") 
{
    console.log("You have just earned 10 points");
}