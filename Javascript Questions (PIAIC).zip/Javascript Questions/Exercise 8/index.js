// The first code with comments
// In this code, I have used operations to get the result of number "8"

console.log("Addtion: ", (5+3));
console.log("Subtraction: ", (11-3));
console.log("Multiplication: ", (2*4));
console.log("Division: ", (16/2));



//The second code with comments
// In this code, I have composed two variables by storing author name in new var such as "quote"
let famous_person = "Mae West"
let quote = `${famous_person} once said, "You only live once, but if you do it right, once is enough."`

console.log(quote);