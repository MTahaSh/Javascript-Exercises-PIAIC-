console.log("Addtion: ", (5+3));
console.log("Subtraction: ", (11-3));
console.log("Multiplication: ", (2*4));
console.log("Division: ", (16/2));