const places = ["Sydney","Morocco","London","Paris","Birmingham"]

console.log(places);

const sorted_arr = places.slice().sort();   
console.log(sorted_arr);
console.log(places);

const reverse_alpha_arr = sorted_arr.slice().reverse();
console.log(reverse_alpha_arr);
console.log(places);

console.log(places.reverse());
console.log(places.reverse());

console.log(places.sort());
console.log(places.reverse());