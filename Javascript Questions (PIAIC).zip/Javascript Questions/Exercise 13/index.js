let friends = ["Wajahat", "Kamil", "Junaid", "Usman"];

console.log(`Hello ${friends[0]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[1]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[2]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    
console.log(`Hello ${friends[3]}, You have been invited to dinner at my place. I am looking forward to see at 9.`);    